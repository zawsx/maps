# Compare maps

Compares OpenStreetMap to Google Maps.

View: [http://lxbarth.com/compare](http://lxbarth.com/compare)
